import React, { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import "../styles/LostListPage.css";
import emptyImage from "./assets/empty.png";

export default function LostListPage() {
  const navigate = useNavigate();
  const location = useLocation();

  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [order, setOrder] = useState("desc");
  const [status, setStatus] = useState("전체");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6;
  const [search, setSearch] = useState("");

  const queryParams = new URLSearchParams(location.search);
  const urlQuery = queryParams.get("query") || "";
  const cat = queryParams.get("cat") || "전체";
  const user = JSON.parse(localStorage.getItem("user"));

  // 검색어 URL 파라미터 → 내부 state로 동기화
  useEffect(() => {
    setSearch(urlQuery);
  }, [urlQuery]);

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("ko-KR", {
      year: "numeric",
      month: "long",
      day: "numeric",
      weekday: "short"
    });
  };

  const formatExpireDate = (dateString) => {
    const date = new Date(dateString);
    const expireDate = new Date(date.getTime() + 14 * 86400000);
    return expireDate.toLocaleDateString("ko-KR", {
      year: "numeric",
      month: "numeric",
      day: "numeric",
      weekday: "short"
    });
  };

  const handleDelete = async (id) => {
    if (!window.confirm("정말 삭제하시겠습니까?")) return;
    try {
      const res = await fetch(`http://localhost:8090/api/lost-items/${id}`, {
        method: "DELETE",
      });
      if (!res.ok) throw new Error("삭제 실패");
      alert("삭제 완료!");
      window.location.reload();
    } catch (err) {
      alert("에러 발생: " + err.message);
    }
  };

  // 검색조건 API 파라미터 적용
  useEffect(() => {
    async function fetchData() {
      setLoading(true);
      setError(null);
      try {
        const catParam = cat === "전체" ? "" : `&cat=${encodeURIComponent(cat)}`;
        const statusParam = status === "전체" ? "" : `&status=${encodeURIComponent(status)}`;
        // ✅ API에서 query, cat, status, order 다 넘김
        const url = `http://localhost:8090/api/lost-items/search?query=${encodeURIComponent(search)}${catParam}${statusParam}&order=${order}`;

        const res = await fetch(url);
        if (!res.ok) throw new Error("목록을 불러올 수 없습니다.");
        const data = await res.json();
        setItems(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }

    fetchData();
  }, [search, cat, order, status]);

  // ✅ pagination 계산
  const totalPages = Math.ceil(items.length / itemsPerPage);
  const paginated = items.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const handlePageClick = (page) => {
    setCurrentPage(page);
  };

  // ✅ 엔터로 검색
  const handleSearchSubmit = (e) => {
    e.preventDefault();
    // 쿼리 스트링 반영(페이지 리로드X)
    navigate(`?query=${encodeURIComponent(search)}&cat=${encodeURIComponent(cat)}`);
  };

  return (
    <div className="lost-list-wrapper">
      <h1 className="lost-list-title" style={{ textAlign: "center", color: "#21761d", marginTop: 0, marginBottom: "18px" }}>
        <span role="img" aria-label="box" style={{ fontSize: "2.1rem", verticalAlign: "-5px" }}>📦</span>
        <span style={{ fontSize: "2rem", fontWeight: 700, marginLeft: 8 }}>물건을 찾아가세요!</span>
      </h1>

      {/* ✅ 크고 둥근 검색창 (가운데, 통일된 스타일) */}
      <form onSubmit={handleSearchSubmit} style={{ display: "flex", justifyContent: "center", margin: "0 0 22px 0" }}>
  <input
    type="text"
    placeholder="제목 또는 내용 검색"
    value={search}
    onChange={(e) => setSearch(e.target.value)}
    style={{
      width: "90%",
      minWidth: "340px",
      maxWidth: "620px",      // 아주 넓게
      padding: "6px 32px",    // 세로 얇게, 가로 넉넉
      height: "38px",         // 높이 고정(더 슬림하게)
      borderRadius: "18px",   // 덜 둥글게
      border: "1.5px solid #bcbcbc",
      outline: "none",
      fontSize: "1rem",
      color: "#444",
      background: "#fff",
      boxSizing: "border-box",
      margin: "0 auto",
      boxShadow: "0 2px 8px rgba(60,100,80,0.04)",
      transition: "border-color 0.2s"
    }}
  />
</form>


      {/* ✅ 최신순/상태 드롭다운 */}
      <div className="lost-list-filters" style={{
        display: "flex", justifyContent: "center", gap: "16px", marginBottom: "24px"
      }}>
        <select
          value={order}
          onChange={(e) => setOrder(e.target.value)}
          style={{
            padding: "8px 16px",
            borderRadius: "10px",
            border: "1px solid #ccc",
            fontSize: "0.95rem",
            background: "#fff",
            fontWeight: "normal",
            cursor: "pointer",
            minWidth: "120px"
          }}
        >
          <option value="desc">📅 최신순</option>
          <option value="asc">📆 오래된순</option>
        </select>
        <select
          value={status}
          onChange={(e) => setStatus(e.target.value)}
          style={{
            padding: "8px 16px",
            borderRadius: "10px",
            border: "1px solid #ccc",
            fontSize: "0.95rem",
            background: "#fff",
            fontWeight: "normal",
            cursor: "pointer",
            minWidth: "120px"
          }}
        >
          <option value="전체">📦 전체</option>
          <option value="미수령">📭 미수령</option>
          <option value="수령완료">✅ 수령완료</option>
        </select>
      </div>

      {loading && (
        <div className="spinner-container"><div className="spinner"></div></div>
      )}
      {error && <p className="lost-list-error">{error}</p>}

      {!loading && items.length === 0 && (
        <div className="lost-list-empty">
          <img src={emptyImage} alt="결과 없음" />
          <p>검색 결과가 없습니다.</p>
        </div>
      )}

      {!loading &&
        paginated.map((item) => (
          <div
            className={`lost-item-card ${item.claimed_by ? "claimed" : ""}`}
            key={item.id}
            onClick={() => navigate(`/found/${item.id}`)}
          >
            <div className="thumbnail-box">
              <img src={`http://localhost:8090${item.image}`} alt="썸네일" />
              {item.claimed_by && (
                <div className="claimed-badge">✅ 수령완료</div>
              )}
            </div>
            <div className="lost-item-body">
              <h3 className="lost-item-title">{item.title}</h3>
              <p className="meta">📍 {item.location}</p>
              <p className="meta">🗓 {formatDate(item.date)}</p>
              <p className="meta" style={{ color: "#d32f2f", fontWeight: 500 }}>
                ⏳ 보관 기한: {formatExpireDate(item.created_at)}
              </p>
            </div>
            {user?.role === "admin" && (
              <button
                className="delete-btn"
                onClick={(e) => {
                  e.stopPropagation();
                  handleDelete(item.id);
                }}
              >
                🗑 삭제
              </button>
            )}
          </div>
        ))}

      {/* ✅ 페이지네이션 */}
      {totalPages > 1 && (
        <div style={{ textAlign: "center", marginTop: "20px" }}>
          {Array.from({ length: totalPages }, (_, i) => i + 1).map((pageNum) => (
            <button
              key={pageNum}
              onClick={() => handlePageClick(pageNum)}
              style={{
                padding: "8px 12px",
                margin: "0 4px",
                borderRadius: "8px",
                border: "1px solid #ccc",
                background: currentPage === pageNum ? "#ffcc80" : "#fff",
                fontWeight: currentPage === pageNum ? "bold" : "normal",
                cursor: "pointer",
              }}
            >
              {pageNum}
            </button>
          ))}
          <p style={{ marginTop: "8px", fontSize: "0.85rem", color: "#666" }}>
            현재 페이지: {currentPage} / {totalPages}
          </p>
        </div>
      )}
    </div>
  );
}
